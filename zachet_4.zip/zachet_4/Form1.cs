﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace zachet_4
{
    public partial class Form1 : Form
    {
        List<char> simvols = new List<char>();
        List<int> numbers = new List<int>();
        List<string> colors = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }
        
        private void AddNew(char newSimvols, int newNumbers, string newColors)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                    if (textBox1.Text != "")
                    {
                        if (File.Exists(textBox1.Text))
                        {
                            StreamReader sr = File.OpenText(textBox1.Text);
                            int j = 0;
                            while (!sr.EndOfStream)
                            {
                                string st = sr.ReadLine();
                                string[] str = st.Split(' ');
                                for (int i = 0; i < str.Length; i++)
                                {
                                    if (j == 0)
                                    {
                                        simvols.Add(Convert.ToChar(str[i]));
                                    }
                                    if (j == 1)
                                    {
                                        numbers.Add(Convert.ToInt32(str[i]));
                                    }
                                    if (j == 2)
                                    {
                                        colors.Add(str[i]);
                                    }
                                }
                                j++;
                            }

                            var vivod = from simvol in simvols
                                        from number in numbers
                                        from color in colors
                                        select new { Simvols = simvol, Numbers = number, Colors = color };

                            foreach (var a in vivod)
                            {
                                listBox1.Items.Add($"Буква = {a.Simvols}, число = {a.Numbers}, цвет = {a.Colors}");
                            }
                        }
                        else MessageBox.Show("Такого файла не существует");
                    }
                    else MessageBox.Show("Название введено не корректно");
            }
            catch { MessageBox.Show("Данные в файле введены не верно"); }
            button1.Enabled = false;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="text.txt"&&textBox1.Text!="")
            {
                button1.Enabled = true;
            }
            else { MessageBox.Show("Чтобы разблокировать кнопку введите корректное название файла"); }
        }
    }
}
